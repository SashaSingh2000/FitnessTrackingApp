# Project Title

Fit Snap is a simple fitness app for entering user data such as name, age, height, weight, activity level, and more to ontain a BMR, and daily caloric intake. It also displays the weather for the day and other factors such as high and lows of the day, and it also displays hikes near the user's location to help them identify activities to do.


## Description

The design features of this app are as follows:

1. The app displays contents well on both mobile and tablet devices.
2. All modules names on-screen are always present on screen. 
3. All buttons on the homepage are icons descriptive of where that page leads to. 
4. User data can be changed at any state of the app.
6. The app follows a material guideline of using the same color themes and fonts.
8. The app works even if device is rotated, the back button is hit inside the app, and if a user switches out of the app to another and comes back.
9. The app is well tested using integration testing.
10. Data is dynamic and will only require a name when a profile is initiated.
11. The user is able to view a summary of their entered data at anytime.

Required Functionality (Modules):
1. I want the app to take in my name, age, location (city and country), height, weight, sex, and “activity level”, and store a full profile picture for me. I’d like the app to show a little thumbnail version of that same profile picture of me at the top right.
2. I want the app to have a module that estimates my basal metabolic rate (BMR), the number of calories I need to survive. This app should then tell me my daily target calorie intake.
3. I want to be able to use the app to find nice hikes near me with the tap of a button and show them to me on Google Maps.
4. I want to be able to see today’s weather for my current city at the tap of a button.
5. I want to be able to see how my caloric intake changes as I change my activity level; this means showing my caloric intake somewhere visibly

## Getting Started
Run the code on Android Studio with the Andoid sdk version 33 or make sure to update gradle dependencies and sync if you aren't working with version 33.

## Help

Make sure you are running the app on the latest update, and remember to hit the elephant icon on the right to do a proper gradle sync.

## Authors

Sasha Singh, Audrey Olson, Bella Bertagnolli, Alyssa Johnson

##Sources
Weather: https://youtu.be/67EJqkcjrzY
https://youtu.be/dm-jan0YORg
https://youtu.be/FtmI0qqQsl8
https://www.youtube.com/watch?v=MOx2MJOpXdM

Hikes/Maps: https://www.youtube.com/watch?v=r6LhxNYuu-o&t=132s
https://www.youtube.com/watch?v=9dC1uvl-Qig&t=853s

## Version History

* 1.0 Initial Release: Project 1
