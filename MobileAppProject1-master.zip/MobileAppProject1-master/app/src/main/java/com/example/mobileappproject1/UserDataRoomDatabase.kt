package com.example.mobileappproject1

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import kotlin.jvm.Volatile
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [UserDataTable::class], version = 2, exportSchema = false)
abstract class UserDataRoomDatabase : RoomDatabase() {
    abstract fun userDataDao(): UserDataDao

    // Make the db singleton. Could in theory
    // make this an object class, but the companion object approach
    // is nicer (imo)
    companion object {
        @Volatile
        private var mInstance: UserDataRoomDatabase? = null
        fun getDatabase(
            context: Context,
            scope : CoroutineScope
        ): UserDataRoomDatabase {
            return mInstance?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    UserDataRoomDatabase::class.java, "userData.db"
                )
                    .addCallback(RoomDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                mInstance = instance
                instance
            }
        }

        private class RoomDatabaseCallback(
            private val scope: CoroutineScope
        ): RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                mInstance?.let { database ->
                    scope.launch(Dispatchers.IO){
                        populateDbTask(database.userDataDao())
                    }
                }
            }
        }

        suspend fun populateDbTask (userDataDao: UserDataDao) {
            userDataDao.insert(UserDataTable("Dummy_name",0, "Dummy_loc", 0.0, 0.0, "Male", 1, "dummy_path", "dummy_path", 0, 0))
        }
    }
}