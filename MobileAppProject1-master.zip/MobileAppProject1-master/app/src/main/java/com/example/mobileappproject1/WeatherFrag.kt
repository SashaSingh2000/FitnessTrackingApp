package com.example.mobileappproject1

import android.content.Context
import android.content.res.Resources
import android.os.Bundle
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.viewModels
import androidx.core.content.res.ResourcesCompat
import androidx.core.os.HandlerCompat
import androidx.fragment.app.Fragment
import org.json.JSONException
import java.lang.ref.WeakReference
import java.util.concurrent.Executors
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt

class WeatherFragment : Fragment(), View.OnClickListener {
    private var mEtLocation: EditText? = null
    private var mTvTemp: TextView? = null
    private var mTvPress: TextView? = null
    private var mTvHum: TextView? = null
    private var mTvFeelsLike: TextView? = null
    private var mTvSunrise: TextView? = null
    private var mTvSunset: TextView? = null
    private var mTvWindSpeed: TextView? = null
    private var mTvWeatherType: TextView? = null
    private var mWeatherData: WeatherDataJava? = null
    private var mBtSubmit: Button? = null
    private var mTvDateTime: TextView? = null
    private var mTvTempF: TextView? = null
    private var mTvBackG: ImageView? = null
    private var mSvBackG: ScrollView? = null
    private var mLlTopBackG: LinearLayout? = null
    private var mLlBottomBackG: LinearLayout? = null
    private var mTvWeatherIcon: ImageView? = null
    private var mButtonBackToHome: Button? = null
    private var mDataPasser: WeatherDataInterface? = null
    var context: WeatherFragment? = null
    var res: Resources? = null
    var context1: WeatherFragment? = null
    var res1: Resources? = null
    private var mWeatherViewModel: WeatherViewModel? = null


    interface WeatherDataInterface {
        fun backToHomeClicked()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mDataPasser = try {
            context as WeatherDataInterface
        } catch (e: java.lang.ClassCastException) {
            null
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        context = this
        res = requireContext().resources
        context1 = this
        res1 = context1!!.resources

        //Grab instance of view model
        mWeatherViewModel = ViewModelProvider(requireActivity())[WeatherViewModel::class.java]
        //Set observer
        mWeatherViewModel!!.data.observe(viewLifecycleOwner, weatherObserver)

        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_weather, container, false)
        //Get the edit text and all the text views
        mEtLocation = view.findViewById<View>(R.id.et_location) as EditText
        mTvTemp = view.findViewById<View>(R.id.tv_temp) as TextView
        mTvPress = view.findViewById<View>(R.id.tv_pressure) as TextView
        mTvHum = view.findViewById<View>(R.id.tv_humidity) as TextView
        mTvFeelsLike = view.findViewById<View>(R.id.tv_feels_like) as TextView
        mTvSunrise = view.findViewById<View>(R.id.tv_sunrise) as TextView
        mTvSunset = view.findViewById<View>(R.id.tv_sunset) as TextView
        mTvWeatherType = view.findViewById<View>(R.id.tv_weather_type) as TextView
        mTvWindSpeed = view.findViewById<View>(R.id.tv_windspeed) as TextView
        mTvDateTime = view.findViewById<View>(R.id.tv_date_and_time) as TextView
        mTvTempF = view.findViewById<View>(R.id.tv_temp_fahrenheit) as TextView
        mTvBackG = view.findViewById<View>(R.id.iv_weather_bg) as ImageView
        mSvBackG = view.findViewById<View>(R.id.sv_weather) as ScrollView
        mLlTopBackG = view.findViewById<View>(R.id.ll_main_bg_above) as LinearLayout
        mLlBottomBackG = view.findViewById<View>(R.id.ll_main_bg_below) as LinearLayout
        mTvWeatherIcon = view.findViewById<View>(R.id.iv_weather_icon) as ImageView
        if (savedInstanceState != null) {
            val temp = savedInstanceState.getString("tvTemp")
            val hum = savedInstanceState.getString("tvHum")
            val press = savedInstanceState.getString("tvPress")
            val feelsLike = savedInstanceState.getString("tvFeelsLike")
            val sunrise = savedInstanceState.getString("tvSunrise")
            val sunset = savedInstanceState.getString("tvSunset")
            val windSpeed = savedInstanceState.getString("tvWindSpeed")
            val weatherType = savedInstanceState.getString("tvWeatherType")
            val dateTime = savedInstanceState.getString("tvDateTime")
            val tempF = savedInstanceState.getString("tvTempF")
            val backBg = savedInstanceState.getString("tvBackBg")
            val weatherIcon = savedInstanceState.getString("tvWeatherIcon")
            if (temp != null) mTvTemp!!.text = "" + temp
            if (hum != null) mTvHum!!.text = "" + hum
            if (press != null) mTvPress!!.text = "" + press
            if (feelsLike != null) mTvFeelsLike!!.text = "" + feelsLike
            if (sunrise != null) mTvSunrise!!.text = "" + sunrise
            if (sunset != null) mTvSunset!!.text = "" + sunset
            if (windSpeed != null) mTvWindSpeed!!.text = "" + windSpeed
            if (weatherType != null) mTvWeatherType!!.text = "" + weatherType
            if (dateTime != null) mTvDateTime!!.text = "" + dateTime
            if (tempF != null) mTvTempF!!.text = "" + tempF
        }
        mBtSubmit = view.findViewById<View>(R.id.button_submit) as Button
        mBtSubmit!!.setOnClickListener(this)
        mButtonBackToHome = view.findViewById<View>(R.id.button_home) as Button
        mButtonBackToHome!!.setOnClickListener(this)
        return view
    }


    //create an observer that watches the LiveData<WeatherData> object
    private val weatherObserver: Observer<WeatherData> =
        Observer { weatherData -> // Update the UI if this data variable changes
            if (weatherData != null) {
                mTvTemp!!.text =
                    "" + (weatherData.temperature.temp - 273.15).roundToInt() + " C"
                mTvHum!!.text = "" + weatherData.currentCondition.humidity + "%"
                mTvPress!!.text = "" + weatherData.currentCondition.pressure + " hPa"
                mTvDateTime!!.text = "" + weatherData.currentCondition.dateTime + "AM"
                mTvSunrise!!.text = "sunrise" + weatherData.currentCondition.sunrise + ""
                mTvSunset!!.text = "sunset" + weatherData.currentCondition.sunset + ""
                mTvFeelsLike!!.text = "feels like" + weatherData.currentCondition.feelsLike + ""
//                    mTvTemp!!.text =
//                        "" + Math.round(weatherData.temperature.temp - 273.15) + " C"
                mTvHum!!.text =
                    "" + weatherData.currentCondition.humidity + "%"
                mTvPress!!.text = "" + weatherData.currentCondition.pressure
                mTvFeelsLike!!.text =
                    "Feels Like " + Math.round(weatherData.currentCondition.feelsLike - 273.15) + " C"
                mTvSunrise!!.text =
                    "" + weatherData.currentCondition.sunrise + " AM"
                mTvSunset!!.text =
                    "" + weatherData.currentCondition.sunset + " PM"
                mTvWindSpeed!!.text =
                    "" + weatherData.currentCondition.windSpeed
                mTvWeatherType!!.text = "" + weatherData.currentCondition.descr
                mTvDateTime!!.text = "" + weatherData.currentCondition.dateTime
                mTvTempF!!.text =
                    "" + Math.round((9 / 5) * (weatherData.temperature.temp - 273) + 32)
                val backBg = weatherData.currentCondition.backG
                setBackgroundAndWeatherIcon(
                    backBg,
                    context,
                    res!!
                )
            }
        }



    override fun onClick(view: View) {
        when (view.id) {
            R.id.button_submit -> {

                //Get the string from the edit text and sanitize the input
                val inputFromEt = mEtLocation!!.text.toString().replace(' ', '&')
                loadWeatherData(inputFromEt)
            }

        }
        when (view.id) {
            R.id.button_home -> {
                mDataPasser!!.backToHomeClicked()
            }
        }
    }


    private fun loadWeatherData(location: String?) {
        //pass the location in to the view model
        mWeatherViewModel!!.setLocation(location!!)
    }



    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tvTemp", mTvTemp!!.text.toString())
        outState.putString("tvHum", mTvHum!!.text.toString())
        outState.putString("tvPress", mTvPress!!.text.toString())
        outState.putString("tvFeelsLike", mTvFeelsLike!!.text.toString())
        outState.putString("tvSunrise", mTvSunrise!!.text.toString())
        outState.putString("tvSunset", mTvSunset!!.text.toString())
        outState.putString("tvWindSpeed", mTvWindSpeed!!.text.toString())
        outState.putString("tvWeatherType", mTvWeatherType!!.text.toString())
        outState.putString("tvDateTime", mTvDateTime!!.text.toString())
        outState.putString("tvTempF", mTvTempF!!.text.toString())
        outState.putString("tvBackBg", mTvBackG!!.drawable.toString())
        outState.putString("tvWeatherIcon", mTvWeatherIcon!!.drawable.toString())
    }
            fun setBackgroundAndWeatherIcon(
                backBg: String?,
                wf: WeatherFragment?,
                res: Resources
            ) {
                    if (backBg == "Thunderstorm") {
                        mTvBackG!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.thunderstorm_bg,
                                null
                            )
                        )
                        mSvBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.thunderstorm_bg,
                            null
                        )
                        mLlTopBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.thunderstorm_bg,
                            null
                        )
                        mLlBottomBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.thunderstorm_bg,
                            null
                        )
                        mTvWeatherIcon!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.thunderstorm,
                                null
                            )
                        )
                    } else if (backBg == "Clear") {
                        mTvBackG!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.clear_bg,
                                null
                            )
                        )
                        mSvBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.clear_bg,
                            null
                        )
                        mLlTopBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.clear_bg,
                            null
                        )
                        mLlBottomBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.clear_bg,
                            null
                        )
                        mTvWeatherIcon!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.clear,
                                null
                            )
                        )
                    } else if (backBg == "Drizle") {
                        mTvBackG!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.drizzle_bg,
                                null
                            )
                        )
                        mSvBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.drizzle_bg,
                            null
                        )
                        mLlTopBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.drizzle_bg,
                            null
                        )
                        mLlBottomBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.drizzle_bg,
                            null
                        )
                        mTvWeatherIcon!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.drizzle,
                                null
                            )
                        )
                    } else if (backBg == "Rain") {
                        mTvBackG!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.rainy_bg,
                                null
                            )
                        )
                        mSvBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.rainy_bg,
                            null
                        )
                        mLlTopBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.rainy_bg,
                            null
                        )
                        mLlBottomBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.rainy_bg,
                            null
                        )
                        mTvWeatherIcon!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.rain,
                                null
                            )
                        )
                    } else if (backBg == "Snow") {
                        mTvBackG!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.snow_bg,
                                null
                            )
                        )
                        mSvBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.snow_bg,
                            null
                        )
                        mLlTopBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.snow_bg,
                            null
                        )
                        mLlBottomBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.snow_bg,
                            null
                        )
                        mTvWeatherIcon!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.snow,
                                null
                            )
                        )
                    } else if (backBg == "Clouds") {
                        mTvBackG!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.clouds_bg,
                                null
                            )
                        )
                        mSvBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.clouds_bg,
                            null
                        )
                        mLlTopBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.clouds_bg,
                            null
                        )
                        mLlBottomBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.clouds_bg,
                            null
                        )
                        mTvWeatherIcon!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.clouds,
                                null
                            )
                        )
                    } else {
                        mTvBackG!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.mist_bg,
                                null
                            )
                        )
                        mSvBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.mist_bg,
                            null
                        )
                        mLlTopBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.mist_bg,
                            null
                        )
                        mLlBottomBackG!!.background = ResourcesCompat.getDrawable(
                            res,
                            R.drawable.mist_bg,
                            null
                        )
                        mTvWeatherIcon!!.setImageDrawable(
                            ResourcesCompat.getDrawable(
                                res,
                                R.drawable.mist,
                                null
                            )
                        )
                    }
                }
            }



