package com.example.mobileappproject1;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

//Declare methods as static. We don't want to create objects of this class.
public class JSONWeatherUtilsJava {
    public static WeatherDataJava getWeatherData(String data) throws JSONException{
        WeatherDataJava weatherData = new WeatherDataJava();

        //Start parsing JSON data
        JSONObject jsonObject = new JSONObject(data); //Must throw JSONException

        WeatherDataJava.CurrentCondition currentCondition = weatherData.getCurrentCondition();
        JSONObject jsonMain = jsonObject.getJSONObject("main");
        currentCondition.setHumidity(jsonMain.getInt("humidity"));
        currentCondition.setPressure(jsonMain.getInt("pressure"));
        currentCondition.setFeelsLike(jsonMain.getInt("feels_like"));


        JSONObject jsonSys = jsonObject.getJSONObject("sys");
        String sunset = jsonSys.getString("sunset");
        String sunsetFormatted = getDateTimeFromEpoch(sunset, "h:mm");
        currentCondition.setSunset(sunsetFormatted);

        String sunrise = jsonSys.getString("sunrise");
        String sunriseFormatted = getDateTimeFromEpoch(sunrise, "h:mm");
        currentCondition.setSunrise(sunriseFormatted);

        String dT = jsonObject.getString("dt");
        String dtFormatted = getDateTimeFromEpoch(dT, "dd MMMM, h:mm a ");
        currentCondition.setDateTime(dtFormatted);

        JSONObject jsonWind = jsonObject.getJSONObject("wind");
        currentCondition.setWindSpeed(jsonWind.getDouble("speed"));

        try {
            JSONArray array = jsonObject.getJSONArray("weather");
            JSONObject conditionObject = array.getJSONObject(0);
            String description = conditionObject.getString("description");
            currentCondition.setDescr(description);

            String weatherMainBG = conditionObject.getString("main");
            currentCondition.setBackG(weatherMainBG);

        }
        catch(JSONException ex){
            ex.printStackTrace();
        }



        weatherData.setCurrentCondition(currentCondition);

        //Get the temperature, wind and cloud data.
        WeatherDataJava.Temperature temperature = weatherData.getTemperature();
        WeatherDataJava.Wind wind = weatherData.getWind();
        WeatherDataJava.Clouds clouds = weatherData.getClouds();
        temperature.setMaxTemp(jsonMain.getDouble("temp_max"));
        temperature.setMinTemp(jsonMain.getDouble("temp_min"));
        temperature.setTemp(jsonMain.getDouble("temp"));
        weatherData.setTemperature(temperature);

        return weatherData;
    }


    private static String getDateTimeFromEpoch(String epochTime, String pattern) {
        //convert seconds to milliseconds
        long unix_seconds = Long.parseLong(epochTime);

        Date date = new Date(unix_seconds * 1000L);
        // format of the date
        SimpleDateFormat jdf = new SimpleDateFormat(pattern);
        String java_date = jdf.format(date);
        return java_date;
    }

}


