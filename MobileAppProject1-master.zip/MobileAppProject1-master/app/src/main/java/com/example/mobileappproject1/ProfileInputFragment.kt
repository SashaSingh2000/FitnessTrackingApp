package com.example.mobileappproject1

import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.location.Geocoder
import android.location.Location
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.google.android.gms.location.*
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import com.google.android.gms.tasks.OnCompleteListener
import android.Manifest.permission.ACCESS_COARSE_LOCATION
import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.location.LocationManager
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.Observer


//Implement View.onClickListener to listen to button clicks. This means we have to override onClick().
class ProfileInputFragment : Fragment(), View.OnClickListener {
    //Create variables for the UI elements that we need to control
    private var mButtonSubmit: Button? = null
    private var mEtFullName: EditText? = null
    private var mNpAge: NumberPicker? = null
    private var mEtLocation: TextView? = null
    private var mNpHeight: NumberPicker? = null
    private var mNpWeight: NumberPicker? = null
    private var mSpGender: Spinner? = null
    private var mButtonCamera: Button? = null
    private var mButtonLoc: Button? = null
    private var mSbActivity: SeekBar? = null

    // Camera and Profile Picture related --- START
    private var mfullImage_photoPath: String? = null
    private var mthumbnailImage_photoPath: String? = null
    private var mFullPhotoURI: Uri? = null
    private var mPhotoFile: File? = null
    private var tookPicture: Boolean = false
    private var newestThumbnail: Bitmap? = null
    private var mIVThumbnailPic: ImageView? = null
    private var mTempFullImagePath: String? = null
    private var mDataPasser: ProfileInputDataInterface? = null
    var mFusedLocationClient: FusedLocationProviderClient? = null
    var geocoder: Geocoder? = null
    var PERMISSION_ID = 44

    private var mUserDataViewModel: UserDataViewModel? = null

    interface ProfileInputDataInterface {
        fun submitClicked()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mDataPasser = try {
            context as ProfileInputDataInterface
        } catch (e: java.lang.ClassCastException) {
            null
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile_input, container, false)

        //Grab instance of view model
        mUserDataViewModel = ViewModelProvider(requireActivity())[UserDataViewModel::class.java]
        //Set observer
        mUserDataViewModel!!.data.observe(viewLifecycleOwner, nameObserver)

        mFusedLocationClient = context?.let { LocationServices.getFusedLocationProviderClient(it) };
        geocoder = Geocoder(requireActivity().applicationContext, Locale.getDefault())

        // Get UI elements
        mEtFullName = view.findViewById(R.id.et_name)
        mNpAge = view.findViewById(R.id.numberpicker_age)
        mEtLocation = view.findViewById(R.id.tv_location)
        mNpHeight = view.findViewById(R.id.numberpicker_height)
        mNpWeight = view.findViewById(R.id.numberpicker_weight)
        mSpGender = view.findViewById(R.id.spinner_gender)
        mSbActivity = view.findViewById(R.id.seekBar_activity)
        mIVThumbnailPic = view.findViewById(R.id.prof_pic)

        // Get the button
        mButtonSubmit = view.findViewById(R.id.button_submit)
        mButtonCamera = view.findViewById(R.id.button_camera)
        mButtonLoc = view.findViewById(R.id.button_loc)

        // Say that this class itself contains the listener.
        mButtonSubmit!!.setOnClickListener(this)
        mButtonCamera!!.setOnClickListener(this)
        mButtonLoc!!.setOnClickListener(this)

        // Set number picker values below
        mNpAge!!.minValue = 0
        mNpAge!!.maxValue = 100
        mNpAge!!.value = 25
        mNpHeight!!.minValue = 48
        mNpHeight!!.maxValue = 83
        mNpHeight!!.value = 68
        var Heights = Array<String>(36) { i -> i.toString() }
        val apostrophe: String = "\'"
        for (i in 4..6)
            for (j in 0..11)
                Heights[((12 * (i - 4)) + j)] = i.toString().plus(apostrophe).plus(j)
        mNpHeight!!.displayedValues = Heights
        mNpWeight!!.minValue = 0
        mNpWeight!!.maxValue = 400
        mNpWeight!!.value = 130

        // Set spinner values
        val spinner: Spinner = view.findViewById(R.id.spinner_gender)
        // Create an ArrayAdapter using the string array and a default spinner layout
        context?.let {
            ArrayAdapter.createFromResource(
                it,
                R.array.gender_array,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                // Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // Apply the adapter to the spinner
                spinner.adapter = adapter
            }
        }


        if(savedInstanceState != null){
            if (!savedInstanceState.getString("fullName").isNullOrBlank()) {
                mEtFullName!!.setText(savedInstanceState.getString("fullName"))
                mNpAge!!.value = savedInstanceState.getString("age")!!.toInt()
                mEtLocation!!.text = savedInstanceState.getString("location")
                mNpHeight!!.value = savedInstanceState.getString("height")!!.toInt()
                mNpWeight!!.value = savedInstanceState.getString("weight")!!.toInt()
                if (savedInstanceState.getString("gender")!! == "Female")
                    mSpGender!!.setSelection(0)
                else if (savedInstanceState.getString("gender")!! == "Male")
                    mSpGender!!.setSelection(1)
                else
                    mSpGender!!.setSelection(2)

                mSbActivity!!.progress = savedInstanceState.getString("activity")!!.toInt()
            }
            mfullImage_photoPath = savedInstanceState.getString("D_fullImagePhotoPath")
            mthumbnailImage_photoPath = savedInstanceState.getString("D_thumbnailPhotoPath")

            if (!mfullImage_photoPath.isNullOrEmpty()) {
                displayThumbnail()
                tookPicture = true
            }
        }
        else {
            if (!mUserDataViewModel!!.getName().isNullOrBlank()) {
                mEtFullName!!.setText(mUserDataViewModel!!.getName())
                mNpAge!!.value = mUserDataViewModel!!.getAge()!!
                mEtLocation!!.text = mUserDataViewModel!!.getLocation()
                mNpHeight!!.value = mUserDataViewModel!!.getHeight()!!.toInt()
                mNpWeight!!.value = mUserDataViewModel!!.getWeight()!!.toInt()
                if (mUserDataViewModel!!.getGender() == "Female")
                    mSpGender!!.setSelection(0)
                else if (mUserDataViewModel!!.getGender() == "Male")
                    mSpGender!!.setSelection(1)
                else
                    mSpGender!!.setSelection(2)

                mSbActivity!!.progress = mUserDataViewModel!!.getActivity()!!
            }
            mfullImage_photoPath = mUserDataViewModel!!.getFullImagePath()
            mthumbnailImage_photoPath = mUserDataViewModel!!.getThumbnailImagePath()

            if (!mfullImage_photoPath.isNullOrEmpty()) {
                displayThumbnail()
                tookPicture = true
            }
        }
        return view;
    }

    // Create an observer that watches the LiveData<UserData> object
    private val nameObserver: Observer<UserData> = Observer { userData ->
    }

    // Handle clicks for ALL buttons here
    override fun onClick(view: View) {
        when (view.id) {
            R.id.button_loc -> {
                // method to get the location
                getLastLocation();
            }
            R.id.button_submit -> {

                //Check if the EditText string is empty
                if (mEtFullName!!.text.toString().isNullOrBlank() || mSpGender!!.selectedItem.toString().isNullOrBlank()) {
                    //Complain that there's no text
                    Toast.makeText(
                        context,
                        "Enter all fields!",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                } else if (!tookPicture) {
                    Toast.makeText(
                        context,
                        "Take a photo",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    //Reward them for submitting their names
                    Toast.makeText(context, "Good job!", Toast.LENGTH_SHORT)
                        .show()

                    mthumbnailImage_photoPath = saveThumbnailToInternalStorage(newestThumbnail!!)

                    mUserDataViewModel?.setName(mEtFullName!!.text.toString().trim())
                    mUserDataViewModel?.setAge(mNpAge!!.value)
                    mUserDataViewModel?.setLocation(mEtLocation!!.text.toString())
                    mUserDataViewModel?.setWeight(mNpWeight!!.value.toDouble())
                    mUserDataViewModel?.setHeight(mNpHeight!!.value.toDouble())
                    mUserDataViewModel?.setGender(mSpGender!!.selectedItem.toString())
                    mUserDataViewModel?.setActivity(mSbActivity!!.progress)
                    mUserDataViewModel?.setFullImagePath(mfullImage_photoPath)
                    mUserDataViewModel?.setThumbnailImagePath(mthumbnailImage_photoPath)
                    mUserDataViewModel?.setCalIntake(calculateCalories())
                    mUserDataViewModel?.setBMR(calculateBMR())

                    mUserDataViewModel?.addUser(mUserDataViewModel?.getName()!!, mUserDataViewModel?.getAge()!!, mUserDataViewModel?.getLocation(),
                        mUserDataViewModel?.getWeight()!!, mUserDataViewModel?.getHeight()!!, mUserDataViewModel?.getGender()!!, mUserDataViewModel?.getActivity()!!,
                        mUserDataViewModel?.getFullImagePath()!!, mUserDataViewModel?.getThumbnailImagePath()!!, mUserDataViewModel?.getCalIntake(), mUserDataViewModel?.getBMR())

                    mDataPasser?.submitClicked()
                }
            }

            // Camera Button Clicked
            R.id.button_camera -> {
                dispatchTakePictureIntent()
            }
        }
    }

    /**
     * Calculates the daily calorie intake so it can display before the user ever navigates to the BMR page
     */
    private fun calculateCalories(): Int {
        return getCalories(
            computeBMR(
                mUserDataViewModel!!.getWeight()!!,
                mUserDataViewModel!!.getHeight()!!,
                mUserDataViewModel!!.getAge()!!,
                mUserDataViewModel!!.getGender()
            ), mUserDataViewModel!!.getActivity()!!
        )
    }

    /**
     * Calculates the user's BMR so it can be saved before the user ever navigates to the BMR page
     */
    private fun calculateBMR(): Int {
        return computeBMR(
            mUserDataViewModel!!.getWeight()!!,
            mUserDataViewModel!!.getHeight()!!,
            mUserDataViewModel!!.getAge()!!,
            mUserDataViewModel!!.getGender()
        )
    }

    /** All location stuff from a mix of these tutorials https://www.geeksforgeeks.org/how-to-get-user-location-in-android/
     * https://developer.android.com/training/location/retrieve-current **/
    @SuppressLint("MissingPermission")
    private fun getLastLocation() {
        // check if permissions are given
        if (checkPermissions()) {

            // check if location is enabled
            if (isLocationEnabled()) {

                // getting last
                // location from
                // FusedLocationClient
                // object
                mFusedLocationClient!!.lastLocation.addOnCompleteListener(OnCompleteListener<Location> { task ->
                    try {
                        val location: Location = task.result
                        if (location == null) {
                            requestNewLocationData()
                        } else {
                            val address =
                                geocoder!!.getFromLocation(location.latitude, location.longitude, 1)
                            var city = address!![0].locality.toString()
                            mEtLocation!!.text = city
                            mUserDataViewModel!!.setLocation(city)
                        }
                    } catch (e: java.lang.NullPointerException) {
                        requestNewLocationData()
                    }

                })
            } else {
                Toast.makeText(context, "Please turn on" + " your location...", Toast.LENGTH_LONG)
                    .show()
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(intent)
            }
        } else {
            // if permissions aren't available,
            // request for permissions
            requestPermissions()
        }
    }

    @SuppressLint("MissingPermission")
    private fun requestNewLocationData() {

        // Initializing LocationRequest
        // object with appropriate methods
        val mLocationRequest = LocationRequest()
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
        mLocationRequest.setInterval(5)
        mLocationRequest.setFastestInterval(0)
        mLocationRequest.setNumUpdates(1)

        // setting LocationRequest
        // on FusedLocationClient
        mFusedLocationClient = context?.let { LocationServices.getFusedLocationProviderClient(it) }
        Looper.myLooper()?.let {
            mFusedLocationClient?.requestLocationUpdates(
                mLocationRequest,
                mLocationCallback,
                it
            )
        }
    }

    private val mLocationCallback: LocationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            val mLastLocation: Location = locationResult.lastLocation
            val address =
                geocoder!!.getFromLocation(mLastLocation.latitude, mLastLocation.longitude, 1)
            var city = address!![0].locality.toString()
            mEtLocation!!.text = city
            mUserDataViewModel!!.setLocation(city)
        }
    }

    // method to check for permissions
    private fun checkPermissions(): Boolean {
        return context?.let {
            ActivityCompat.checkSelfPermission(
                it,
                ACCESS_COARSE_LOCATION
            )
        } == PackageManager.PERMISSION_GRANTED


    }

    // method to request for permissions
    private fun requestPermissions() {
        activity?.let {
            ActivityCompat.requestPermissions(
                it, arrayOf(
                    ACCESS_COARSE_LOCATION,
                    ACCESS_FINE_LOCATION
                ), PERMISSION_ID
            )

        }

    }

    // method to check
    // if location is enabled
    private fun isLocationEnabled(): Boolean {

        val locationManager =
            requireContext().getSystemService(Context.LOCATION_SERVICE) as LocationManager?
        return locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
        // getLastLocation()
        return true
    }

    // If everything is alright then
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_ID) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation()
            }
        }
    }

// Camera and Profile Pic related --- START

    /**
     * Creates the image file where the full image will be stored.
     */
    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            mfullImage_photoPath = absolutePath
            // Save a file: path for use with ACTION_VIEW intents
        }
    }

    /**
     * Launches intent to take picture.
     */
    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            // Create the File where the photo should go
            mPhotoFile = try {
                createImageFile()
            } catch (ex: IOException) {
                // Error occurred while creating the File
                null
            }

            // Continue only if the File was successfully created
            mPhotoFile?.also {
                mFullPhotoURI = context?.let { it1 ->
                    FileProvider.getUriForFile(
                        it1,
                        "com.example.mobileappproject1.fileprovider",
                        it
                    )
                }
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mFullPhotoURI)
                try {
                    cameraLauncher.launch(takePictureIntent)
                } catch (ex: ActivityNotFoundException) {
                    // Do something here
                }
            }
        }
    }

    /**
     * Displays the thumbnail in the ImageView.
     * Also sets the value of the newestThumbnail to keep track of it.
     */
    private fun displayThumbnail() {
        // Get the dimensions of the View
        val targetW: Int = (getResources().getDimension(R.dimen.prof_thumbnail_width)).toInt()
        val targetH: Int = (getResources().getDimension(R.dimen.prof_thumbnail_height)).toInt()

        val thumbImage = ThumbnailUtils.extractThumbnail(
            BitmapFactory.decodeFile(mfullImage_photoPath),
            targetW,
            targetH
        )

        mIVThumbnailPic!!.setImageBitmap(thumbImage)
        // Keep track of most recent thumbnail
        newestThumbnail = thumbImage
    }

    private var cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                displayThumbnail()
                tookPicture = true
            }
        }

    /**
     * Saves newestThumbnail as profileThumbnail.jpg in internal memory.
     *
     * DO NOT REMOVE CITATION - Code from:
     * https://stackoverflow.com/questions/17674634/saving-and-reading-bitmaps-images-from-internal-memory-in-android
     */
    private fun saveThumbnailToInternalStorage(bitmapImage: Bitmap): String? {
        val cw = ContextWrapper(context)
        // path to /data/data/yourapp/app_data/imageDir
        val directory = cw.getDir("imageDir", Context.MODE_PRIVATE)
        // Create imageDir
        val mypath = File(directory, "profileThumbnail.jpg")
        var fos: FileOutputStream? = null
        try {
            fos = FileOutputStream(mypath)
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos)
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                if (fos != null) {
                    fos.close()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        return directory.absolutePath
    }
    // Camera and Profile Pic related --- END

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("fullName", mEtFullName!!.text.toString())
        outState.putString("age", mNpAge!!.value.toString())
        outState.putString("location", mEtLocation!!.text.toString())
        outState.putString("height", mNpHeight!!.value.toString())
        outState.putString("weight", mNpWeight!!.value.toString())
        outState.putString("gender", mSpGender!!.selectedItem.toString())
        outState.putString("activity", mSbActivity!!.progress.toString())
        outState.putString("D_fullImagePhotoPath", mfullImage_photoPath)
        outState.putString("D_thumbnailPhotoPath", mthumbnailImage_photoPath)
    }
}