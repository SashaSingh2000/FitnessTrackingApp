package com.example.mobileappproject1

class UserData {
    var userFullName: String? = null
    var userAge: Int? = null
    var userLocation: String? = null
    var userWeight: Double? = null
    var userHeight: Double? = null
    var userGender: String? = null
    var userActivity: Int? = null
    var userFullImage_photoPath: String? = null
    var userThumbnail_photoPath: String? = null
    var userCalIntake: Int? = null
    var userBMR: Int? = null
}