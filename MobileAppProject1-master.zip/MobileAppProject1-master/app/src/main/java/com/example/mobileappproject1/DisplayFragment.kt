package com.example.mobileappproject1


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider


class DisplayFragment : Fragment(), View.OnClickListener {
    private var mTVName: TextView? = null
    private var mTvAge: TextView? = null
    private var mTvLocation: TextView? = null
    private var mTvGender: TextView? = null
    private var mTvHeight: TextView? = null
    private var mTvWeight: TextView? = null
    private var mTvActivity: TextView? = null
    private var mButtonEdit: Button? = null
    private var mButtonBackToHome: Button? = null
    private var mDataPasser: DisplayDataInterface? = null
    private var mIVFullPic: ImageView? = null

    private var mUserDataViewModel: UserDataViewModel? = null

    interface DisplayDataInterface {
        fun backToHomeClicked()
        fun editDisplayClicked()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mDataPasser = try {
            context as DisplayDataInterface
        } catch (e: java.lang.ClassCastException) {
            null
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_display, container, false)

        //Grab instance of view model
        mUserDataViewModel = ViewModelProvider(requireActivity())[UserDataViewModel::class.java]
        //Set observer
        mUserDataViewModel!!.data.observe(viewLifecycleOwner, nameObserver)

        // Get all UI views
        // User data related
        mTVName = view.findViewById(R.id.tv_name_data)
        mTvAge = view.findViewById(R.id.tv_age_data)
        mTvLocation = view.findViewById(R.id.tv_location_data)
        mTvWeight = view.findViewById(R.id.tv_weight_data)
        mTvHeight = view.findViewById(R.id.tv_height_data)
        mTvGender = view.findViewById(R.id.tv_gender_data)
        mTvActivity = view.findViewById(R.id.tv_activitylvl_data)
        mIVFullPic = view.findViewById<View>(R.id.full_prof_pic) as ImageView
        // Buttons
        mButtonBackToHome = view.findViewById(R.id.btn_display_to_home)
        mButtonEdit = view.findViewById(R.id.btn_edit_display)

        // Say that this class itself contains the listener.
        mButtonBackToHome!!.setOnClickListener(this)
        mButtonEdit!!.setOnClickListener(this)

        // Forces the observer to "activate" so that when user opens profile page for the first time,
        // the page won't be empty since they didn't make any changes to the userdata yet
        mUserDataViewModel!!.forceRefresh()
        return view
    }

    // Create an observer that watches the LiveData<UserData> object
    private val nameObserver: Observer<UserData> = Observer { userData -> // Update the UI if this data variable changes
        if (userData != null) {
            mTVName!!.text = "" + userData.userFullName
            mTvAge!!.text = "" + userData.userAge
            mTvWeight!!.text = "" + userData.userWeight
            val feet = (userData.userHeight!!.toInt() / 12).toString()
            val inches = (userData.userHeight!!.toInt() % 12).toString()
            mTvHeight!!.text = feet + "'" + inches
            mTvActivity!!.text = "" + userData.userActivity
            if (userData.userGender.isNullOrBlank()) {
                Toast.makeText(context, "Empty string received", Toast.LENGTH_SHORT).show()
            }
            else {
                mTvGender!!.text = "" + userData.userGender
            }
            if (userData.userLocation.isNullOrBlank()) {
                mTvLocation!!.text = "No Location Received"
            }
            else {
                mTvLocation!!.text = userData.userLocation
            }
            val fullImage: Bitmap = BitmapFactory.decodeFile(userData.userFullImage_photoPath)
            mIVFullPic!!.setImageBitmap(fullImage)
        }
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btn_display_to_home -> {
                mDataPasser!!.backToHomeClicked()
            }
        }
        when (view.id) {
            R.id.btn_edit_display -> {
                mDataPasser!!.editDisplayClicked()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
//        outState.putString("fullName", mFullName)
//        outState.putString("age", mAgeReceived)
//        outState.putString("location", mLocationReceived)
//        outState.putString("height", mHeightReceived)
//        outState.putString("weight", mWeightReceived)
//        outState.putString("gender", mGenderReceived)
//        outState.putString("activity", mActivityReceived)
//        outState.putString("D_fullImagePhotoPath", mfullImagePhotoPath)
    }
}