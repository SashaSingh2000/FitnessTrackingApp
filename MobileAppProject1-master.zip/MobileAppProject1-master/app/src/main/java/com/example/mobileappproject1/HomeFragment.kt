package com.example.mobileappproject1

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import androidx.fragment.app.Fragment

class HomeFragment : Fragment(), View.OnClickListener {
    private var mButtonProfile: ImageButton? = null
    private var mButtonBMR: ImageButton? = null
    private var mButtonMaps: ImageButton? = null
    private var mWeatherButton: ImageButton? = null

    private var mDataPasser: HomeDataInterface? = null

    interface HomeDataInterface {
        fun profileClicked()
        fun bmrClicked()
        fun hikesClicked()
        fun weatherClicked()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mDataPasser = try {
            context as HomeDataInterface
        } catch (e: java.lang.ClassCastException) {
            null
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        mButtonProfile = view.findViewById(R.id.profilePageButton)
        mButtonBMR = view.findViewById(R.id.bmrButton)
        mButtonMaps = view.findViewById(R.id.hikeMapsButton)
        mWeatherButton = view.findViewById(R.id.weatherButton)

        mButtonProfile!!.setOnClickListener(this)
        mButtonBMR!!.setOnClickListener(this)
        mButtonMaps!!.setOnClickListener(this)
        mWeatherButton!!.setOnClickListener(this)

        return view
    }

    //Handle clicks for ALL buttons here
    override fun onClick(view: View) {
        when (view.id) {
            R.id.profilePageButton -> {
                mDataPasser!!.profileClicked()
            }
            R.id.bmrButton -> {
                mDataPasser!!.bmrClicked()
            }
            R.id.hikeMapsButton -> {
                mDataPasser!!.hikesClicked()
            }
            R.id.weatherButton -> {
                mDataPasser!!.weatherClicked()
            }
        }
    }
}