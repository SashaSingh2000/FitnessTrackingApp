package com.example.mobileappproject1

import androidx.lifecycle.MutableLiveData
import androidx.annotation.WorkerThread
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlin.jvm.Synchronized

class UserDataRepository private constructor(userDataDao: UserDataDao) {
    // This LiveData object that is notified when we've updated user data
    val data = MutableLiveData<UserData>()
    val cals = MutableLiveData<Int>()

    // This flow is triggered when any change happens to the database
    val allUsers: Flow<List<UserDataTable>> = userDataDao.getAllUsers()

    private var mFullName: String? = null
    private var mAge: Int? = null
    private var mLocation: String? = null
    private var mWeight: Double? = null
    private var mHeight: Double? = null
    private var mGender: String? = null
    private var mActivity: Int? = null
    private var mfullImage_photoPath: String? = null
    private var mthumbnail_photoPath: String? = null
    private var mCalIntake: Int? = null
    private var mBMR: Int? = null
    private var mUserDataDao: UserDataDao = userDataDao
    val userData = UserData()


    fun setName(name: String) {
        mFullName = name
    }

    fun getName(): String? {
        return mFullName
    }

    fun setAge(age: Int) {
        mAge = age
    }

    fun getAge(): Int? {
        return mAge
    }

    fun setLocation(location: String?) {
        mLocation = location
    }

    fun getLocation(): String? {
        return mLocation
    }

    fun setWeight(weight: Double) {
        mWeight = weight
    }

    fun getWeight(): Double? {
        return mWeight
    }

    fun setHeight(height: Double) {
        mHeight = height
    }

    fun getHeight(): Double? {
        return mHeight
    }

    fun setGender(gender: String) {
        mGender = gender
    }

    fun getGender(): String? {
        return mGender
    }

    fun setActivity(activity: Int) {
        mActivity = activity
    }

    fun getActivity(): Int? {
        return mActivity
    }

    fun setFullImagePath(fullImagePath: String?) {
        mfullImage_photoPath = fullImagePath
    }

    fun getFullImagePath(): String? {
        return mfullImage_photoPath
    }

    fun setThumbnailImagePath(thumbnailImagePath: String?) {
        mthumbnail_photoPath = thumbnailImagePath
    }

    fun getThumbnailImagePath(): String? {
        return mthumbnail_photoPath
    }

    fun setCalIntake(calIntake: Int?) {
        mCalIntake = calIntake
        if(calIntake != null)
            cals.postValue(calIntake!!)
    }

    fun getCalIntake(): Int? {
        return mCalIntake
    }

    fun setBMR(BMR: Int?) {
        mBMR = BMR
    }

    fun getBMR(): Int? {
        return mBMR
    }


    /**
     * update userData variable with current user information
     */
    fun updateUserDataVariable() {
        userData.userFullName = mFullName
        userData.userAge = mAge
        userData.userLocation = mLocation
        userData.userWeight = mWeight
        userData.userHeight = mHeight
        userData.userGender = mGender
        userData.userActivity = mActivity
        userData.userFullImage_photoPath = mfullImage_photoPath
        userData.userThumbnail_photoPath = mthumbnail_photoPath
        userData.userCalIntake = mCalIntake
        userData.userBMR = mBMR
    }

    fun addUser(
        name: String, age: Int, location: String?, weight: Double, height: Double,
        gender: String, activity: Int, fullImagePath: String, thumbnailPath: String,
        calIntake: Int?, BMR: Int?
    ) {
        mFullName = name
        mAge = age
        mLocation = location
        mWeight = weight
        mHeight = height
        mGender = gender
        mActivity = activity
        mfullImage_photoPath = fullImagePath
        mthumbnail_photoPath = thumbnailPath
        mCalIntake = calIntake
        mBMR = BMR
        updateUserDataVariable()

        // Everything within the scope happens logically sequentially
        mScope.launch(Dispatchers.IO) {

            // After the suspend function returns, Update the View THEN insert into db
            if (mFullName != null) {
                // Populate live data object. But since this is happening in a background thread (the coroutine),
                // we have to use postValue rather than setValue. Use setValue if update is on main thread
                // FIX THIS: data.postValue(JSONWeatherUtils.getWeatherData(mJsonString))

                //val userData = UserData()
                data.postValue(userData)
                // insert into db. This will trigger a flow
                // that updates a recyclerview. All db ops should happen
                // on a background thread
                insert()
            }
        }
    }

    /**
     * Forces the livedata observer to activate by inserting already existing user data
     */
    fun forceRefresh() {
        updateUserDataVariable()

        // Everything within the scope happens logically sequentially
        mScope.launch(Dispatchers.IO) {

            // After the suspend function returns, Update the View THEN insert into db
            if (mFullName != null) {
                // Populate live data object. But since this is happening in a background thread (the coroutine),
                // we have to use postValue rather than setValue. Use setValue if update is on main thread
                data.postValue(userData)
                // insert into db. All db ops should happen on a background thread
                insert()
            }
        }
    }

    @WorkerThread
    suspend fun insert() {
        if (mFullName != null &&
            mAge != null &&
            mWeight != null &&
            mHeight != null &&
            mGender != null &&
            mActivity != null &&
            mfullImage_photoPath != null &&
            mthumbnail_photoPath != null
        ) {
            mUserDataDao.insert(
                UserDataTable(
                    mFullName!!,
                    mAge!!,
                    mLocation,
                    mWeight!!,
                    mHeight!!,
                    mGender!!,
                    mActivity!!,
                    mfullImage_photoPath!!,
                    mthumbnail_photoPath!!,
                    mCalIntake,
                    mBMR
                )
            )
        }
    }


    // Make the repository singleton. Could in theory
    // make this an object class, but the companion object approach
    // is nicer (imo)
    companion object {
        private var mInstance: UserDataRepository? = null
        private lateinit var mScope: CoroutineScope

        @Synchronized
        fun getInstance(
            userDataDao: UserDataDao,
            scope: CoroutineScope
        ): UserDataRepository {
            mScope = scope
            return mInstance ?: synchronized(this) {
                val instance = UserDataRepository(userDataDao)
                mInstance = instance
                instance
            }
        }
    }
}