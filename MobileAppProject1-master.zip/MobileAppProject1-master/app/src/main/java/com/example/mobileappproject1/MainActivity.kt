package com.example.mobileappproject1

import android.content.*
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import android.content.Context
import android.content.ContextWrapper
import android.content.ActivityNotFoundException
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import kotlin.math.roundToInt


class MainActivity : AppCompatActivity(), HomeFragment.HomeDataInterface,
    ProfileInputFragment.ProfileInputDataInterface, DisplayFragment.DisplayDataInterface,
    BMRFragment.BMRDataInterface, ListFragment.ListDataInterface, WeatherFragment.WeatherDataInterface {

    private var mUser: String? = null

    private lateinit var preferences: SharedPreferences
    private lateinit var preferenceEditor: SharedPreferences.Editor

    private var currFragment: Fragment? = null
    private var mListFragment: Fragment? = null

    // Toolbar related
    private lateinit var toolbar: androidx.appcompat.widget.Toolbar
    private var menu: Menu? = null
    private var mTv_BMR_toolbar: TextView? = null

    // Initialize the view model here. One per activity.
    // While initializing, we'll also inject the repository.
    // However, standard view model constructor only takes a context to
    // the activity. We'll need to define our own constructor, but this
    // requires writing our own view model factory.
    val mUserDataViewModel: UserDataViewModel by viewModels {
        UserDataViewModelFactory((application as WeatherApplication).repository_usr)
    }
     val mWeatherViewModel: WeatherViewModel by viewModels {
        WeatherViewModelFactory((application as WeatherApplication).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preferences = getSharedPreferences("Fit_Snap_Preferences", Context.MODE_PRIVATE)
        preferenceEditor = preferences.edit()

        // Get the toolbar
        toolbar = findViewById(R.id.main_toolbar)
        setSupportActionBar(toolbar)
        updateProfileIcon()
        mTv_BMR_toolbar = findViewById(R.id.bmr_toolbar)

        //Grab instance of view model
        //mUserDataViewModel = ViewModelProvider(this)[UserDataViewModel::class.java]
        //Set observer
        mWeatherViewModel.data.observe(this, weatherObserver)
        mUserDataViewModel.data.observe(this, nameObserver)
        mUserDataViewModel.allUsers.observe(this, flowObserver)
        mUserDataViewModel.calData.observe(this, calObserver)

        if (savedInstanceState != null) {
            currFragment = supportFragmentManager.findFragmentByTag("current_fragment")
        } else {
            mUser = preferences.getString("User", null)
            currFragment = HomeFragment()
            val fTrans = supportFragmentManager.beginTransaction()
            fTrans.replace(R.id.fl_content, currFragment as HomeFragment, "current_fragment")
            fTrans.commit()
        }
        if (mUserDataViewModel!!.getCalIntake() != null) {
            mTv_BMR_toolbar!!.text = mUserDataViewModel!!.getCalIntake().toString() + "\ncal"
            mTv_BMR_toolbar!!.visibility = View.VISIBLE
        }
        //make items list here
        //Populate the list with data

        val items = arrayOf(
            "Home", "Profile", "Hikes", "Weather",
            "BMR",
        )

        //Put this into a bundle
        val fragmentBundle = Bundle()
        //send it over
        fragmentBundle.putStringArray("item_list", items)

        //Create the fragment
        mListFragment = ListFragment()

        //Pass data to the fragment
        mListFragment!!.arguments = fragmentBundle

        //If we're on a tablet, the master fragment appears on the left pane. If we're on a phone,
        //it takes over the whole screen
        val fTrans = supportFragmentManager.beginTransaction()
        if (isTablet) {
            //Pane 1: Master list
            fTrans.replace(
                R.id.fl_frag_masterlist_container_tablet,
                mListFragment!!,
                "frag_masterlist"
            )
        }
        fTrans.commit()

    }

    private val isTablet: Boolean
        get() = resources.getBoolean(R.bool.isTablet)

    override fun profileClicked() {
        if (mUserDataViewModel!!.getName().isNullOrBlank()) {
            // Disables the profile icon when the user has no previously saved data
            val profileIcon = menu!!.findItem(R.id.action_profile)
            profileIcon.isEnabled = false

            val fTrans = supportFragmentManager.beginTransaction()
            fTrans.replace(R.id.fl_content, ProfileInputFragment(), "current_fragment")
            fTrans.commit()
        } else {
            val fTrans = supportFragmentManager.beginTransaction()
            fTrans.replace(R.id.fl_content, DisplayFragment(), "current_fragment")
            fTrans.commit()
        }
    }

    private val nameObserver: Observer<UserData> = Observer { userData ->
        if (userData != null) {
            if (userData.userCalIntake != -1) {
                // update daily calorie intake on toolbar
                mTv_BMR_toolbar!!.text = userData.userCalIntake.toString() + "\ncal"
                mTv_BMR_toolbar!!.visibility = View.VISIBLE
            }
        }
    }

    private val calObserver: Observer<Int> = Observer { calories ->
        if (calories != null) {
            if (calories != -1) {
                // update daily calorie intake on toolbar
                mTv_BMR_toolbar!!.text = calories.toString() + "\ncal"
                mTv_BMR_toolbar!!.visibility = View.VISIBLE
            }
        }
    }

    private val flowObserver: Observer<List<UserDataTable>> =
        Observer { userDataTableList ->
            if (userDataTableList != null){
                userDataTableList.forEach {
                    if(mUser == it.name){
                        mUserDataViewModel.setName(it.name)
                        mUserDataViewModel.setAge(it.age)
                        mUserDataViewModel.setLocation(it.location)
                        mUserDataViewModel.setWeight(it.weight)
                        mUserDataViewModel.setHeight(it.height)
                        mUserDataViewModel.setGender(it.gender)
                        mUserDataViewModel.setActivity(it.activity)
                        mUserDataViewModel.setThumbnailImagePath(it.thumbnail)
                        mUserDataViewModel.setFullImagePath(it.fullImage)
                        mUserDataViewModel.setCalIntake(it.calIntake)
                        mUserDataViewModel.setBMR(it.BMR)
                    }
                }
            }
        }



    override fun bmrClicked() {
        val fTrans = supportFragmentManager.beginTransaction()
        fTrans.replace(R.id.fl_content, BMRFragment(), "current_fragment")
        fTrans.commit()
    }

    override fun hikesClicked() {
        //We have to grab the search term and construct a URI object from it.
        val searchUri = Uri.parse("geo:?q=hikes near me")

        //Create the implicit intent
        val mapIntent = Intent(Intent.ACTION_VIEW, searchUri)

        //If there's an activity associated with this intent, launch it
        try {
            startActivity(mapIntent)
        } catch (ex: ActivityNotFoundException) {
            //handle errors here
        }
    }


    //create an observer that watches the LiveData<WeatherData> object
    private val weatherObserver: Observer<WeatherData> =
        Observer { weatherData -> // Update the UI if this data variable changes
            if (weatherData != null) {
                //just do observation in actual weather page
            }
        }

    override fun weatherClicked() {
        val fTrans = supportFragmentManager.beginTransaction()
        fTrans.replace(R.id.fl_content, WeatherFragment(), "current_fragment")
        fTrans.commit()
    }

    override fun submitClicked() {
        // Enable the profile icon once the profile has been saved
        val profileIcon = menu!!.findItem(R.id.action_profile)
        profileIcon.isEnabled = true

        updateProfileIcon()

        mUser = mUserDataViewModel.getName()

        preferenceEditor.putString("User", mUser)
        preferenceEditor.commit()

        val displayFragment = DisplayFragment()
        val fTrans = supportFragmentManager.beginTransaction()
        fTrans.replace(R.id.fl_content, displayFragment, "current_fragment")
        fTrans.commit()
    }

    override fun backToHomeClicked() {
        val fTrans = supportFragmentManager.beginTransaction()
        fTrans.replace(R.id.fl_content, HomeFragment(), "current_fragment")
        fTrans.commit()
    }

    override fun editDisplayClicked() {
        val fTrans = supportFragmentManager.beginTransaction()
        fTrans.replace(R.id.fl_content, ProfileInputFragment(), "current_fragment")
        fTrans.commit()
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        this.menu = menu
        updateProfileIcon()
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.action_profile -> {
            profileClicked()
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }

    /**
     * Loads the profile thumbnail from internal storage, makes it circular, and draws the thumbnail in the toolbar.
     */
    private fun updateProfileIcon() {
        try {
            // Gets the path the profile thumbnail icon is saved in
            val cw = ContextWrapper(applicationContext)
            val directory = cw.getDir("imageDir", Context.MODE_PRIVATE)
            val savedPath = directory.absolutePath

            // Gets the file of the profile thumbnail icon and converts to bitmap
            val file = File(savedPath, "profileThumbnail.jpg")
            var thumbnailBitmap = BitmapFactory.decodeStream(FileInputStream(file))
            thumbnailBitmap = getCircularBitmap(thumbnailBitmap)

            // Makes bitmap a drawable so MenuItem icon can draw it
            val d: Drawable = BitmapDrawable(resources, thumbnailBitmap)
            val profileItem: MenuItem? = menu?.findItem(R.id.action_profile)
            if (profileItem != null) {
                profileItem.icon = d
            }
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        }
    }

    /**
     * Makes a bitmap circular.
     *
     * DO NOT REMOVE CITATION - Code from:
     * https://www.tutorialspoint.com/android-how-to-crop-circular-area-from-bitmap
     */
    private fun getCircularBitmap(srcBitmap: Bitmap): Bitmap? {
        // Calculate the circular bitmap width with border
        val squareBitmapWidth = Math.min(srcBitmap.width, srcBitmap.height)
        // Initialize a new instance of Bitmap
        val dstBitmap = Bitmap.createBitmap(
            squareBitmapWidth,  // Width
            squareBitmapWidth,  // Height
            Bitmap.Config.ARGB_8888 // Config
        )
        val canvas = Canvas(dstBitmap)
        // Initialize a new Paint instance
        val paint = Paint()
        paint.setAntiAlias(true)
        val rect = Rect(0, 0, squareBitmapWidth, squareBitmapWidth)
        val rectF = RectF(rect)
        canvas.drawOval(rectF, paint)
        paint.setXfermode(PorterDuffXfermode(PorterDuff.Mode.SRC_IN))
        // Calculate the left and top of copied bitmap
        val left = ((squareBitmapWidth - srcBitmap.width) / 2).toFloat()
        val top = ((squareBitmapWidth - srcBitmap.height) / 2).toFloat()
        canvas.drawBitmap(srcBitmap, left, top, paint)
        // Free the native object associated with this bitmap.
        srcBitmap.recycle()
        // Return the circular bitmap
        return dstBitmap
    }

    fun updatePreferenceEditor() {
        preferenceEditor.putString("FullName", mUserDataViewModel!!.getName())
        preferenceEditor.putString("Age", mUserDataViewModel!!.getAge().toString())
        preferenceEditor.putString("Location", mUserDataViewModel!!.getLocation())
        preferenceEditor.putString("Height", mUserDataViewModel!!.getHeight().toString())
        preferenceEditor.putString("Weight", mUserDataViewModel!!.getWeight().toString())
        preferenceEditor.putString("Gender", mUserDataViewModel!!.getGender())
        preferenceEditor.putString("Activity", mUserDataViewModel!!.getActivity().toString())
        preferenceEditor.putString("D_fullImagePhotoPath", mUserDataViewModel!!.getFullImagePath())
        preferenceEditor.putString(
            "D_thumbnailPhotoPath",
            mUserDataViewModel!!.getThumbnailImagePath()
        )
        preferenceEditor.putString("CalIntake", mUserDataViewModel!!.getCalIntake().toString())
        preferenceEditor.commit()
    }

    override fun onPause() {
        super.onPause()
        updatePreferenceEditor()
    }


    override fun onSaveInstanceState(outState: Bundle) {

        //Save the view hierarchy
        super.onSaveInstanceState(outState)

        //Put them in the outgoing Bundle
        /*
        outState.putString("User", mUserDataViewModel.getName())

        outState.putString("Age", mAge)
        outState.putString("Location", mLocation)
        outState.putString("Weight", mWeight)
        outState.putString("Height", mHeight)
        outState.putString("Gender", mGender)
        outState.putString("Activity", mActivity)
        outState.putString("D_fullImagePhotoPath", mfullImage_photoPath)
        outState.putString("D_thumbnailPhotoPath", mthumbnail_photoPath)
        outState.putString("D_calIntake", mCalIntake)
         */
    }


}