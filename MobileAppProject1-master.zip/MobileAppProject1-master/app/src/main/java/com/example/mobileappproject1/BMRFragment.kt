package com.example.mobileappproject1

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.Button
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider

fun computeBMR(weight: Double, height: Double, age: Int, gender: String?): Int {
    //convert pounds to KG
    val weightKG: Double = 0.45359237 * weight
    //convert inches to CM
    val heightCM: Double = 2.54 * height

    return when (gender) {
        "Male" -> {
            (88.362 + (13.397 * weightKG) + (4.799 * heightCM) - (5.677 * age.toDouble())).toInt()
        }
        "Female" -> {
            (447.593 + (9.247 * weightKG) + (3.098 * heightCM) - (4.330 * age.toDouble())).toInt()
        }
        "Other" -> {
            (((88.362 + (13.397 * weightKG) + (4.799 * heightCM) - (5.677 * age.toDouble())) + (447.593 + (9.247 * weightKG) + (3.098 * heightCM) - (4.330 * age))) / 2).toInt()
        }
        else -> {
            -1
        }
    }
}

fun getCalories(BMR: Int, ActivityLevel: Int?): Int {
    return when (ActivityLevel) {
        5 -> {
            (BMR * 1.9).toInt()
        }
        4 -> {
            (BMR * 1.725).toInt()
        }
        3 -> {
            (BMR * 1.55).toInt()
        }
        2 -> {
            (BMR * 1.375).toInt()
        }
        else -> {
            (BMR * 1.2).toInt()
        }
    }
}

class BMRFragment : Fragment(), OnSeekBarChangeListener, OnClickListener {
    private var mBMR: Int? = null
    private var mActivityType: String? = null

    private var mTvUserBMR: TextView? = null
    private var mTvBMR: TextView? = null
    private var mTvUserCalories: TextView? = null
    private var mTvCalories: TextView? = null
    private var mTvUserActivityLevel: TextView? = null
    private var mTvActivityLevel: TextView? = null
    private var mSbActivityLevel: SeekBar? = null
    private var mBtnBackHome: Button? = null

    private var mDataPasser: BMRDataInterface? = null

    private var mUserDataViewModel: UserDataViewModel? = null


    interface BMRDataInterface {
        fun backToHomeClicked()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mDataPasser = try {
            context as BMRDataInterface
        } catch (e: java.lang.ClassCastException) {
            null
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_bmr, container, false)

        //Grab instance of view model
        mUserDataViewModel = ViewModelProvider(requireActivity())[UserDataViewModel::class.java]
        //Set observer
        mUserDataViewModel!!.data.observe(viewLifecycleOwner, nameObserver)


        mTvUserBMR = view.findViewById(R.id.tv_user_BMR)
        mTvBMR = view.findViewById(R.id.tv_BMR)
        mTvUserCalories = view.findViewById(R.id.tv_user_Calories)
        mTvCalories = view.findViewById(R.id.tv_Calories)
        mTvUserActivityLevel = view.findViewById(R.id.tv_user_ActivityLevel)
        mTvActivityLevel = view.findViewById(R.id.tv_ActivityLevel)
        mSbActivityLevel = view.findViewById(R.id.seekBar_activityLevel)
        mBtnBackHome = view.findViewById(R.id.btn_bmr_to_home)

        mBMR = if (mUserDataViewModel?.getGender().isNullOrEmpty())
            -1
        else computeBMR(
            mUserDataViewModel?.getWeight()!!,
            mUserDataViewModel?.getHeight()!!,
            mUserDataViewModel?.getAge()!!,
            mUserDataViewModel?.getGender()
        )

        setActivityLevel()

        mSbActivityLevel!!.setOnSeekBarChangeListener(this)
        mBtnBackHome!!.setOnClickListener(this)

        return view
    }

    private val nameObserver: Observer<UserData> = Observer { userData ->
        if (userData != null) {

            mBMR = if (userData.userGender.isNullOrEmpty())
                -1
            else computeBMR(
                userData.userWeight!!.toDouble(),
                userData.userHeight!!.toDouble(),
                userData.userAge!!.toInt(),
                userData.userGender
            )

            setActivityLevel()
        }
    }


    private fun setActivityLevel() {
        if (mBMR == -1) {
            mTvUserBMR!!.text = ""
            mTvBMR!!.text = ""
            mTvUserCalories!!.text = getString(R.string.no_BMR_information)
            mTvCalories!!.text = ""
            mTvUserActivityLevel!!.text = ""
            mTvActivityLevel!!.text = ""
            mSbActivityLevel!!.progress = 1
        } else {
            mUserDataViewModel?.setBMR(mBMR)
            mUserDataViewModel?.setCalIntake(
                getCalories(
                    mBMR!!,
                    mUserDataViewModel?.getActivity()
                )
            )

            when (mUserDataViewModel?.getActivity()) {
                5 -> {
                    mActivityType = "Professional Athlete"
                }
                4 -> {
                    mActivityType = "Very Active"
                }
                3 -> {
                    mActivityType = "Moderately Active"
                }
                2 -> {
                    mActivityType = "Lightly Active"
                }
                else -> {
                    mActivityType = "Sedentary"
                }
            }

            mTvUserBMR!!.text = mBMR.toString()
            mTvUserCalories!!.text = mUserDataViewModel?.getCalIntake().toString()
            mTvUserActivityLevel!!.text = mActivityType
            mSbActivityLevel!!.progress = mUserDataViewModel?.getActivity()!!.toInt()
        }
    }

    override fun onProgressChanged(p0: SeekBar?, newActivity: Int, p2: Boolean) {
        mUserDataViewModel?.setActivity(newActivity)
        setActivityLevel()
        // Sends the daily target calorie intake to the toolbar
    }

    override fun onStartTrackingTouch(p0: SeekBar?) {
        //Do nothing
    }

    override fun onStopTrackingTouch(p0: SeekBar?) {
        //Do nothing
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btn_bmr_to_home -> {
                mDataPasser!!.backToHomeClicked()
            }
        }
    }
}