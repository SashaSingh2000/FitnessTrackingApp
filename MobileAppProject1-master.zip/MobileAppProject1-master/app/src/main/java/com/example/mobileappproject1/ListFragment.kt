package com.example.mobileappproject1

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment

class ListFragment : Fragment(), View.OnClickListener {
    private var mButtonProfile: Button? = null
    private var mButtonBMR: Button? = null
    private var mButtonMaps: Button? = null
    private var mButtonWeather: Button? = null
    private var mButtonHome: Button? = null
    private var mDataPasser: ListDataInterface? = null

    interface ListDataInterface {
        fun profileClicked()
        fun bmrClicked()
        fun hikesClicked()
        fun backToHomeClicked()
        fun weatherClicked()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mDataPasser = try {
            context as ListDataInterface
        } catch (e: java.lang.ClassCastException) {
            null
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_list, container, false)

        mButtonProfile = view.findViewById(R.id.buttonprofile)
        mButtonBMR = view.findViewById(R.id.buttonbmr)
        mButtonMaps = view.findViewById(R.id.buttonhike)
        mButtonHome = view.findViewById(R.id.buttonhome)
        mButtonWeather = view.findViewById(R.id.buttonweather)

        mButtonProfile!!.setOnClickListener(this)
        mButtonBMR!!.setOnClickListener(this)
        mButtonMaps!!.setOnClickListener(this)
        mButtonHome!!.setOnClickListener(this)
        mButtonWeather!!.setOnClickListener(this)

        return view
    }

    //Handle clicks for ALL buttons here
    override fun onClick(view: View) {
        when (view.id) {
            R.id.buttonprofile -> {
                mDataPasser!!.profileClicked()
            }
            R.id.buttonbmr -> {
                mDataPasser!!.bmrClicked()
            }
            R.id.buttonhike -> {
                mDataPasser!!.hikesClicked()
            }
            R.id.buttonhome -> {
                mDataPasser!!.backToHomeClicked()
            }
            R.id.buttonweather -> {
                mDataPasser!!.weatherClicked()
            }
        }
    }
}
