package com.example.mobileappproject1

import androidx.lifecycle.*

class UserDataViewModel(repository: UserDataRepository) : ViewModel() {
    // Connect a live data object to the current bit of user data
    private val jsonData: LiveData<UserData> = repository.data
    private val cals: LiveData<Int> = repository.cals
    private var mUserDataRepository: UserDataRepository = repository

    // Use a second live data here to show entire contents of db
    // This casts a flow in the repo as a live data so an observer in the view
    // can watch it. If you want to observe variables in the repo from the viewmodel, use
    // observeForever (not recommended as it's almost never needed)
    val allUsers: LiveData<List<UserDataTable>> = repository.allUsers.asLiveData()

    /**
     * Forces the livedata observer to activate by inserting already existing user data
     */
    fun forceRefresh() {
        mUserDataRepository.forceRefresh()
    }
    fun setName(name: String) {
        mUserDataRepository.setName(name)
    }

    fun getName(): String? {
        return mUserDataRepository.getName()
    }

    fun setAge(age: Int) {
        mUserDataRepository.setAge(age)
    }

    fun getAge(): Int? {
        return mUserDataRepository.getAge()
    }

    fun setLocation(location: String?) {
        mUserDataRepository.setLocation(location)
    }

    fun getLocation(): String? {
        return mUserDataRepository.getLocation()
    }

    fun setWeight(weight: Double) {
        mUserDataRepository.setWeight(weight)
    }

    fun getWeight(): Double? {
        return mUserDataRepository.getWeight()
    }

    fun setHeight(height: Double) {
        mUserDataRepository.setHeight(height)
    }

    fun getHeight(): Double? {
        return mUserDataRepository.getHeight()
    }

    fun setGender(gender: String) {
        mUserDataRepository.setGender(gender)
    }

    fun getGender(): String? {
        return mUserDataRepository.getGender()
    }

    fun setActivity(activity: Int) {
        mUserDataRepository.setActivity(activity)
    }

    fun getActivity(): Int? {
        return mUserDataRepository.getActivity()
    }

    fun setFullImagePath(fullImagePath: String?) {
        mUserDataRepository.setFullImagePath(fullImagePath)
    }

    fun getFullImagePath(): String? {
        return mUserDataRepository.getFullImagePath()
    }

    fun setThumbnailImagePath(thumbnailImagePath: String?) {
        mUserDataRepository.setThumbnailImagePath(thumbnailImagePath)
    }

    fun getThumbnailImagePath(): String? {
        return mUserDataRepository.getThumbnailImagePath()
    }

    fun setCalIntake(calIntake: Int?) {
        mUserDataRepository.setCalIntake(calIntake)
    }

    fun getCalIntake(): Int? {
        return mUserDataRepository.getCalIntake()
    }

    fun setBMR(BMR: Int?) {
        mUserDataRepository.setBMR(BMR)
    }

    fun getBMR(): Int? {
        return mUserDataRepository.getBMR()
    }

    fun addUser(
        name: String, age: Int, location: String?, weight: Double, height: Double,
        gender: String, activity: Int, fullImagePath: String, thumbnailPath: String,
        calIntake: Int?, BMR: Int?
    ) {
        mUserDataRepository.addUser(name, age, location, weight, height, gender, activity, fullImagePath, thumbnailPath, calIntake, BMR)
    }

    val data: LiveData<UserData> get() = jsonData

    val calData: LiveData<Int> get() = cals

}

// This factory class allows us to define custom constructors for the view model
class UserDataViewModelFactory(private val repository: UserDataRepository) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserDataViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UserDataViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
