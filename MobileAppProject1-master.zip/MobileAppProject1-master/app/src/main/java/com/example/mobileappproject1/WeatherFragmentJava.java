package com.example.mobileappproject1;

import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.os.HandlerCompat;
import androidx.fragment.app.Fragment;

import org.json.JSONException;

import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class WeatherFragmentJava extends Fragment implements View.OnClickListener {

    private EditText mEtLocation;
    private TextView mTvTemp;
    private TextView mTvPress;
    private TextView mTvHum;
    private TextView mTvFeelsLike;
    private TextView mTvSunrise;
    private TextView mTvSunset;
    private TextView mTvWindSpeed;
    private TextView mTvWeatherType;
    private WeatherDataJava mWeatherData;
    private Button mBtSubmit;
    private TextView mTvDateTime;
    private TextView mTvTempF;
    private ImageView mTvBackG;
    private ImageView mTvWeatherIcon;
    private static FetchWeatherTask mFetchWeatherTask = new FetchWeatherTask();

    WeatherFragmentJava context;
    Resources res;
    WeatherFragmentJava context1;
    Resources res1;

    public WeatherFragmentJava() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        context = this;
        res = context.getResources();
        context1 = this;
        res1 = context1.getResources();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weather, container, false);
        //Get the edit text and all the text views
        mEtLocation = (EditText) view.findViewById(R.id.et_location);
        mTvTemp = (TextView) view.findViewById(R.id.tv_temp);
        mTvPress = (TextView) view.findViewById(R.id.tv_pressure);
        mTvHum = (TextView) view.findViewById(R.id.tv_humidity);
        mTvFeelsLike = (TextView) view.findViewById(R.id.tv_feels_like);
        mTvSunrise = (TextView) view.findViewById(R.id.tv_sunrise);
        mTvSunset = (TextView) view.findViewById(R.id.tv_sunset);
        mTvWeatherType = (TextView) view.findViewById(R.id.tv_weather_type);
        mTvWindSpeed= (TextView) view.findViewById(R.id.tv_windspeed);
        mTvDateTime = (TextView) view.findViewById(R.id.tv_date_and_time);
        mTvTempF = (TextView) view.findViewById(R.id.tv_temp_fahrenheit);
        mTvBackG = (ImageView) view.findViewById(R.id.iv_weather_bg);
        mTvWeatherIcon = (ImageView) view.findViewById(R.id.iv_weather_icon);
        if(savedInstanceState!=null) {
            String temp = savedInstanceState.getString("tvTemp");
            String hum = savedInstanceState.getString("tvHum");
            String press = savedInstanceState.getString("tvPress");
            String feelsLike = savedInstanceState.getString("tvFeelsLike");
            String sunrise = savedInstanceState.getString("tvSunrise");
            String sunset = savedInstanceState.getString("tvSunset");
            String windSpeed = savedInstanceState.getString("tvWindSpeed");
            String weatherType = savedInstanceState.getString("tvWeatherType");
            String dateTime = savedInstanceState.getString("tvDateTime");
            String tempF = savedInstanceState.getString("tvTempF");
            String backBg = savedInstanceState.getString("tvBackBg");
            String weatherIcon = savedInstanceState.getString("tvWeatherIcon");
            if (temp != null)
                mTvTemp.setText(""+temp);
            if (hum != null)
                mTvHum.setText(""+hum);
            if (press != null)
                mTvPress.setText(""+press);
            if (feelsLike != null)
                mTvFeelsLike.setText(""+feelsLike);
           if (sunrise != null)
                mTvSunrise.setText(""+sunrise);
           if (sunset != null)
                mTvSunset.setText(""+sunset);
           if (windSpeed != null)
                mTvWindSpeed.setText(""+windSpeed);
           if(weatherType != null)
               mTvWeatherType.setText(""+weatherType);
           if(dateTime != null)
               mTvDateTime.setText(""+dateTime);
           if(tempF != null)
               mTvTempF.setText(""+tempF);

           FetchWeatherTask.setBackgroundAndWeatherIcon(backBg, this, res);

        }
        mFetchWeatherTask.setWeakReference(this); //make sure we're always pointing to current version of fragment
        mBtSubmit = (Button) view.findViewById(R.id.button_submit);
        mBtSubmit.setOnClickListener(this);
        return view;
    }
    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.button_submit:{
                //Get the string from the edit text and sanitize the input
                String inputFromEt = mEtLocation.getText().toString().replace(' ','&');
                loadWeatherData(inputFromEt);
            }
            break;
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("tvTemp",mTvTemp.getText().toString());
        outState.putString("tvHum",mTvHum.getText().toString());
        outState.putString("tvPress",mTvPress.getText().toString());
        outState.putString("tvFeelsLike",mTvFeelsLike.getText().toString());
        outState.putString("tvSunrise",mTvSunrise.getText().toString());
        outState.putString("tvSunset",mTvSunset.getText().toString());
        outState.putString("tvWindSpeed",mTvWindSpeed.getText().toString());
        outState.putString("tvWeatherType", mTvWeatherType.getText().toString());
        outState.putString("tvDateTime", mTvDateTime.getText().toString());
        outState.putString("tvTempF", mTvTempF.getText().toString());
        outState.putString("tvBackBg", mTvBackG.getDrawable().toString());
        outState.putString("tvWeatherIcon", mTvWeatherIcon.getDrawable().toString());
    }

    private void loadWeatherData(String location){
      mFetchWeatherTask.execute(this,location);
    }



    private static class FetchWeatherTask {
        WeakReference<WeatherFragmentJava> weatherFragmentWeakReference;
        private ExecutorService executorService = Executors.newSingleThreadExecutor();
        private Handler mainThreadHandler = HandlerCompat.createAsync(Looper.getMainLooper());

        public void setWeakReference(WeatherFragmentJava ref)
        {
            weatherFragmentWeakReference = new WeakReference<WeatherFragmentJava>(ref);
        }
        public void execute(WeatherFragmentJava ref, String location){

            executorService.execute(new Runnable(){
                @Override
                public void run(){
                    String jsonWeatherData;
                    URL weatherDataURL = NetworkUtilsJava.buildURLFromString(location);
                    jsonWeatherData = null;
                    try{
                        jsonWeatherData = NetworkUtilsJava.getDataFromURL(weatherDataURL);
                        postToMainThread(jsonWeatherData);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }

        private void postToMainThread(String jsonWeatherData)
        {
            WeatherFragmentJava localRef = weatherFragmentWeakReference.get();
            mainThreadHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (jsonWeatherData != null) {
                        try {
                            localRef.mWeatherData = JSONWeatherUtilsJava.getWeatherData(jsonWeatherData);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (localRef.mWeatherData != null) {
                            setWeatherParameters(localRef);
                        }
                    }
                }
            });
        }

        private static void setWeatherParameters(WeatherFragmentJava localRef) {

            localRef.mTvTemp.setText("" + Math.round(localRef.mWeatherData.getTemperature().getTemp() - 273.15) + " C");
            localRef.mTvHum.setText("" + localRef.mWeatherData.getCurrentCondition().getHumidity() + "%");
            localRef.mTvPress.setText("" + localRef.mWeatherData.getCurrentCondition().getPressure());
            localRef.mTvFeelsLike.setText("Feels Like " +Math.round(localRef.mWeatherData.getCurrentCondition().getFeelsLike() - 273.15) + " C");
            localRef.mTvSunrise.setText("" + localRef.mWeatherData.getCurrentCondition().getSunrise() + " AM");
            localRef.mTvSunset.setText("" + localRef.mWeatherData.getCurrentCondition().getSunset() + " PM");
            localRef.mTvWindSpeed.setText("" + localRef.mWeatherData.getCurrentCondition().getWindSpeed());
            localRef.mTvWeatherType.setText(""+ localRef.mWeatherData.getCurrentCondition().getDescr());
            localRef.mTvDateTime.setText("" + localRef.mWeatherData.getCurrentCondition().getDateTime());
            localRef.mTvTempF.setText(""+Math.round(9/5 * (localRef.mWeatherData.getTemperature().getTemp() - 273) + 32));
            String backBg = localRef.mWeatherData.getCurrentCondition().getBackG();
            setBackgroundAndWeatherIcon(backBg, localRef, localRef.getResources());

        }

        private static void setBackgroundAndWeatherIcon(String backBg, WeatherFragmentJava wf, Resources res) {

            if(backBg.equals("Thunderstorm")){
                wf.mTvBackG.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.thunderstorm_bg, null));
                wf.mTvWeatherIcon.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.thunderstorm, null));
            } else if (backBg.equals("Clear")) {
                wf.mTvBackG.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.clear_bg, null));
                wf.mTvWeatherIcon.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.clear, null));
            } else if (backBg.equals("Drizle")) {
                wf.mTvBackG.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.drizzle_bg, null));
                wf.mTvWeatherIcon.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.drizzle, null));
            } else if (backBg.equals("Rain")) {
                wf.mTvBackG.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.rainy_bg, null));
                wf.mTvWeatherIcon.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.rain, null));
            } else if (backBg.equals("Snow")) {
                wf.mTvBackG.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.snow_bg, null));
                wf.mTvWeatherIcon.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.snow, null));
            } else if (backBg.equals("Clouds")) {
                wf.mTvBackG.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.clouds_bg, null));
                wf.mTvWeatherIcon.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.clouds, null));
            } else {
                wf.mTvBackG.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.mist_bg, null));
                wf.mTvWeatherIcon.setImageDrawable(ResourcesCompat.getDrawable(res, R.drawable.mist, null));
            }

        }
    }
}