package com.example.mobileappproject1

import androidx.room.*

import kotlinx.coroutines.flow.Flow

@Dao
interface UserDataDao {
    // Insert ignore
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(userDataTable: UserDataTable)

    // Delete all
    @Query("DELETE FROM user_data_table")
    suspend fun deleteAll()

    @Query("SELECT * from user_data_table")
    fun getAllUsers(): Flow<List<UserDataTable>>
}