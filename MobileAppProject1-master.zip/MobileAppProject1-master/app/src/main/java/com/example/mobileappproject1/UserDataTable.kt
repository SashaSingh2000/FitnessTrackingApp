package com.example.mobileappproject1

import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import androidx.room.Entity

@Entity(tableName = "user_data_table")
data class UserDataTable(
    @field:ColumnInfo(name = "name")
    @field:PrimaryKey
    var name: String,
    @field:ColumnInfo(name = "age")
    var age: Int,
    @field:ColumnInfo(name = "location")
    var location: String?,
    @field:ColumnInfo(name = "weight")
    var weight: Double,
    @field:ColumnInfo(name = "height")
    var height: Double,
    @field:ColumnInfo(name = "gender")
    var gender: String,
    @field:ColumnInfo(name = "activity")
    var activity: Int,
    @field:ColumnInfo(name = "fullImage")
    var fullImage: String,
    @field:ColumnInfo(name = "thumbnail")
    var thumbnail: String,
    @field:ColumnInfo(name = "calIntake")
    var calIntake: Int?,
    @field:ColumnInfo(name = "BMR")
    var BMR: Int?
)