package com.example.mobileappproject1

import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

//Declare methods as static. We don't want to create objects of this class.
object JSONWeatherUtils {
    @Throws(JSONException::class)
    fun getWeatherData(data: String?): WeatherData {
        val weatherData = WeatherData()

        //Start parsing JSON data
        val jsonObject = JSONObject(data) //Must throw JSONException
        val currentCondition: WeatherData.CurrentCondition = weatherData.CurrentCondition()
        val jsonMain = jsonObject.getJSONObject("main")
        currentCondition.humidity = jsonMain.getInt("humidity").toDouble()
        currentCondition.pressure = jsonMain.getInt("pressure").toDouble()
        currentCondition.feelsLike = jsonMain.getInt("feels_like").toDouble()
        //currentCondition.setHumidity(jsonMain.getInt("humidity").toDouble())
       // currentCondition.setPressure(jsonMain.getInt("pressure").toDouble())
        //currentCondition.setFeelsLike(jsonMain.getInt("feels_like").toDouble())
        val jsonSys = jsonObject.getJSONObject("sys")
        val sunset = jsonSys.getString("sunset")
        val sunsetFormatted = getDateTimeFromEpoch(sunset, "h:mm")
        currentCondition.sunset = sunsetFormatted
        //currentCondition.setSunset(sunsetFormatted)
        val sunrise = jsonSys.getString("sunrise")
        val sunriseFormatted = getDateTimeFromEpoch(sunrise, "h:mm")
        currentCondition.sunrise = sunriseFormatted
        //currentCondition.setSunrise(sunriseFormatted)
        val dT = jsonObject.getString("dt")
        val dtFormatted = getDateTimeFromEpoch(dT, "dd MMMM, h:mm a ")
        //currentCondition.setDateTime(dtFormatted)
        currentCondition.dateTime = dtFormatted
        val jsonWind = jsonObject.getJSONObject("wind")
        currentCondition.windSpeed = jsonWind.getDouble("speed")
        try {
            val array = jsonObject.getJSONArray("weather")
            val conditionObject = array.getJSONObject(0)
            val description = conditionObject.getString("description")
            currentCondition.descr = description
            val weatherMainBG = conditionObject.getString("main")
            currentCondition.backG = weatherMainBG
        } catch (ex: JSONException) {
            ex.printStackTrace()
        }
        weatherData.currentCondition = currentCondition

        //Get the temperature, wind and cloud data.
        val temperature: WeatherData.Temperature = weatherData.Temperature()
        val wind: WeatherData.Wind = weatherData.Wind()
        val clouds: WeatherData.Clouds = weatherData.Clouds()
        temperature.maxTemp = jsonMain.getDouble("temp_max")
        temperature.minTemp = jsonMain.getDouble("temp_min")
        temperature.temp = jsonMain.getDouble("temp")
        weatherData.temperature = temperature
        return weatherData
    }

    private fun getDateTimeFromEpoch(
        epochTime: String,
        pattern: String
    ): String {
        //convert seconds to milliseconds
        val unix_seconds = epochTime.toLong()
        val date = Date(unix_seconds * 1000L)
        // format of the date
        val jdf = SimpleDateFormat(pattern)
        return jdf.format(date)
    }
}