package com.example.mobileappproject1

import org.junit.Assert
import org.junit.Test
//Tests BMR based off of revised Harris Benedict Equation
class BMRTests {
    @Test
    fun bmr_female(){
        Assert.assertEquals(1396.0, computeBMR(130.0, 65.0, 25, "Female").toDouble(), 1.0)
        Assert.assertEquals(1218.0, computeBMR(50.0, 74.0, 5, "Female").toDouble(), 1.0)
    }
    @Test
    fun bmr_male(){
        Assert.assertEquals(1529.0, computeBMR(130.0, 65.0, 25, "Male").toDouble(), 1.0)
        Assert.assertEquals(1266.0, computeBMR(50.0, 74.0, 5, "Male").toDouble(), 1.0)
    }
    @Test
    fun bmr_other(){
        Assert.assertEquals(1462.5, computeBMR(130.0, 65.0, 25, "Other").toDouble(), 1.0)
        Assert.assertEquals(1242.0, computeBMR(50.0, 74.0, 5, "Other").toDouble(), 1.0)
    }
    @Test
    fun not_computable_Gender(){
        Assert.assertEquals(-1, computeBMR(130.0, 65.0, 25, "ABCDE"))
    }
    @Test
    fun get_calories(){
        Assert.assertEquals(1675.0, getCalories(1396, 1).toDouble(), 1.0)
        Assert.assertEquals(1920.0, getCalories(1396, 2).toDouble(), 1.0)
        Assert.assertEquals(2164.0, getCalories(1396, 3).toDouble(), 1.0)
        Assert.assertEquals(2408.0, getCalories(1396, 4).toDouble(), 1.0)
        Assert.assertEquals(2653.0, getCalories(1396, 5).toDouble(), 1.0)
    }
    @Test
    fun get_calories_outside_activity_level_bounds(){
        Assert.assertEquals(1675.0, getCalories(1396, 6).toDouble(), 1.0)
        Assert.assertEquals(1675.0, getCalories(1396, -1).toDouble(), 1.0)
        Assert.assertEquals(1675.0, getCalories(1396, 100).toDouble(), 1.0)
    }
}